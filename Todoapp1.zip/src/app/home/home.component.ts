import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  itemCount : number = 2;
  btnText: string = 'Add list item'; 
  listItemText;
  listItem=  [];
  index:number;
  isVisible:boolean=true;


  constructor() { }

  ngOnInit(){
    this.itemCount=this.listItem.length;
  }

  addListItem(){
    this.listItem.push(this.listItemText);
    this.listItemText='';
    this.itemCount=this.listItem.length;
  }
  dltListItem(idx){
    this.listItem.splice(idx, 1);
    this.itemCount=this.listItem.length;
  }

  edtListItem(idx){
    this.listItemText=this.listItem[idx];
    this.index=idx;
    this.isVisible=false;
  }
  updListItem(){
    this.listItem.splice(this.index,1,this.listItemText);
    this.listItemText='';
    this.isVisible=true;
  }
}
