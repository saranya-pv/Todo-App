import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  displayedColumns = ['position','firstName','lastName','email', 'contact'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator; 
  @ViewChild(MatSort) sort: MatSort;

  ngOnInit() {

   this.dataSource.paginator = this.paginator;
   this.dataSource.sort = this.sort;  
    
  }

  applyFilter(filterValue: string) {

    this.dataSource.filter = filterValue.trim().toLowerCase();

  }

}

export interface Element {
  position: number;
  firstName: string;
  lastName: string;
  email:string;
  contact:number;
}
const ELEMENT_DATA: Element[] = [
  {position: 1 , firstName:'Saranya' , lastName:'Puthanvarikotil' , email:'spv@gmail.com' , contact:9874561230 },
  {position: 2 , firstName:'Ragesh' , lastName:'Ramachandran' , email:'rr@gmail.com' , contact:9874561230   },
  {position: 3 , firstName:'Rithika' , lastName:'Ragesh' , email:'srv@gmail.com' , contact:9874561230   },
  {position: 4 , firstName:'Zoya' , lastName:'Sabastien' , email:'szs@gmail.com' , contact:9874561230   },
  {position: 5 , firstName:'Saathvika' , lastName:'Sudheesh' , email:'ss@gmail.com' , contact:9874561230   },
  {position: 6 , firstName:'Jayasree' , lastName:'Venu Gopalan' , email:'jv@gmail.com' , contact:9874561230   },
  {position: 7 , firstName:'Venu Gopalan' , lastName:'PV' , email:'vpv@gmail.com' , contact:9874561230   },
  {position: 8 , firstName:'Manikantan' , lastName:'Mani' , email:'mm@gmail.com' , contact:9874561230   },
  {position: 9 , firstName:'Smrutirekha' , lastName:'das' , email:'sdas@gmail.com' , contact:9874561230   },
  {position: 10 , firstName:'Amit' , lastName:'Yadav' , email:'amiyadv@gmail.com' , contact:9874561230   },
  {position: 11 , firstName:'Radhika' , lastName:'Vishak' , email:'radhivishak@gmail.com' , contact:9874561230   },
  {position: 12 , firstName:'Janaki' , lastName:'Nisha' , email:'jn@gmail.com' , contact:9874561230   },
  {position: 13 , firstName:'Meenakshi' , lastName:'Selvam' , email:'ms@gmail.com' , contact:9874561230   },
  {position: 14 , firstName:'Madhuri' , lastName:'Ganesh' , email:'mg@gmail.com' , contact:9874561230   },
  {position: 15, firstName:'Sophie' , lastName:'Evan' , email:'sevan@gmail.com' , contact:9874561230   },
  {position: 16 , firstName:'Priyanka' , lastName:'Jonas' , email:'pj@gmail.com' , contact:9874561230   },
  {position: 17 , firstName:'Ranveer' , lastName:'Deepika' , email:'rdk@gmail.com' , contact:9874561230   }
];

