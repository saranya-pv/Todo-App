export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyByZjO-OqxV-hQ2j8qFVC0SImj74ncPJOo",
    authDomain: "todo-app-bf2d3.firebaseapp.com",
    databaseURL: "https://todo-app-bf2d3.firebaseio.com",
    projectId: "todo-app-bf2d3",
    storageBucket: "todo-app-bf2d3.appspot.com",
    messagingSenderId: "117709141352"
  }
};
